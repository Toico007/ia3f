const caixaPrincipal = document.querySelector('.caixa-prinipal');
const caixaPerguntas = document.querySelector('.caixa-perguntas');
const caixaAlternativas = document.querySelector('.caixa-alternativas');
const caixaResultado = document.querySelector('.caixa-resultado');

const perguntas = [
    {
        enunciado: "pergunta 1",
        alternativas: [
            "Alternativa 1",
            "Alternativa 2"

        ]
    }
]